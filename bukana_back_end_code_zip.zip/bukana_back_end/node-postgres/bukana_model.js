const Pool = require('pg').Pool
const pool = new Pool({
  user: 'citus',
  host: 'localhost',
  database: 'postgres',
  password: 'citus',
  port: 5432,
});

const getusers = () => {
    return new Promise(function(resolve, reject) {
      pool.query('SELECT * FROM users ORDER BY username ASC', (error, results) => {
        if (error) {
          reject(error)
        }
        resolve(results.rows);
      })
    }) 
  }
  const getPatient = () => {
    return new Promise(function(resolve, reject) {
      pool.query('SELECT * FROM patient ORDER BY patient_id ASC', (error, results) => {
        if (error) {
          reject(error)
        }
        resolve(results.rows);
      })
    }) 
  }
  
  const createPatient = (body) => {
    return new Promise(function(resolve, reject) {
      const { patient_id, name, district_id, email, whatsApp_number } = body;
      pool.query(
        'INSERT INTO patient (patient_id, name, district_id, email, whatsApp_number) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [patient_id, name, district_id, email, whatsApp_number],
        (error, results) => {
          if (error) {
            reject(error);
          }
          resolve(`A new patient has been added: ${results.rows[0]}`);
        }
      );
    });
  };
  const getRecord = () => {
    return new Promise(function(resolve, reject) {
      pool.query('SELECT * FROM health_records ORDER BY record_id ASC', (error, results) => {
        if (error) {
          reject(error)
        }
        resolve(results.rows);
      })
    }) 
  }
  const getAppointment = () => {
    return new Promise(function(resolve, reject) {
      pool.query('SELECT * FROM appointment ORDER BY appointment_id ASC', (error, results) => {
        if (error) {
          reject(error)
        }
        resolve(results.rows);
      })
    }) 
  }
  const updateRecord = (body) => {
    return new Promise(function(resolve, reject) {
      const { record_id,patient_id, symptoms, medication, record_date,hospital_id } = body;
      pool.query(
        'INSERT INTO  health_records(record_id,patient_id, symptoms, medication, record_date,hospital_id) VALUES ($1, $2, $3, $4, $5,$6) RETURNING *',
        [record_id,patient_id, symptoms, medication, record_date,hospital_id],
        (error, results) => {
          if (error) {
            reject(error);
          }
          resolve(`Record Updated successfully : ${results.rows[0]}`);
        }
      );
    });
  };
  
  module.exports = {
    getusers,
    createPatient,
    getPatient,
    getRecord,
    updateRecord,
    getAppointment,
    
  }