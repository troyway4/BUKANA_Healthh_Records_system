import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
      <p>Don't have an Account?<b> Visit nearby Hospital to get an account</b></p>
    </div>
  )
}

export default Footer
