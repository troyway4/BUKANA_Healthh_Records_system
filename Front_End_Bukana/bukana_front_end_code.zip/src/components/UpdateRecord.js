import React,{useState} from 'react'
import { useNavigate } from 'react-router-dom';

const UpdateRecord = () => {

  const [record_id, setRecord_id] = useState('');
  const [patient_id, setPatient_id] = useState('');
  const [symptoms, setSymptom] = useState('');
  const [medication, setMedication] = useState('');
  const [record_date, setRecord_date] = useState('');
  const [hospital_id, setHospital_id] = useState('');
 
    const updateRecord = () => {
        fetch('http://localhost:3001/updateRecord', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({record_id,patient_id, symptoms, medication, record_date,hospital_id }),
        })
          .then((response) => {
            if (!response.ok) {
              throw new Error('Failed to update record');
            }
            return response.text();
          })
          .then((data) => {
            alert(data);
            // Additional logic after successful creation
          })
          .catch((error) => {
            console.error(error);
            // Handle the error: display a message or perform any necessary actions
          });
      };
    const navigate = useNavigate();
    const handleCreateClick = () => {
        updateRecord();
        navigate('/result');
      };


  return (
    <div className='updaterecord'>
      <div className='updaterecord1'>
        <input
          type='int'
          placeholder='record_id'
          value={record_id}
          onChange={(e) => setRecord_id(e.target.value)}
        />
        <input
          type='int'
          placeholder='patient_id'
          value={patient_id}
          onChange={(e) => setPatient_id(e.target.value)}
        />
        <input
          type='text'
          placeholder='symptoms'
          value={symptoms}
          onChange={(e) => setSymptom(e.target.value)}
        />
        <input
          type='text'
          placeholder='medication'
          value={medication}
          onChange={(e) => setMedication(e.target.value)}
        />
        <input
          type='date'
          placeholder='record_date'
          value={record_date}
          onChange={(e) => setRecord_date(e.target.value)}
        />
        <input
          type='int'
          placeholder='hospital_id'
          value={hospital_id}
          onChange={(e) => setHospital_id(e.target.value)}
        />
      </div>
      <button className='btn9' onClick={handleCreateClick}>
        Update
      </button>
    </div>
  )
}

export default UpdateRecord
