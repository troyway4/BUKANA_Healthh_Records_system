import React from 'react'
import {Link} from 'react-router-dom'


const Appointment = ({appointment_}) => {
  return (
    <div className='record1'>
          {appointment_.length === 0 ? (
            <h>Patient has no appointment</h>
          ) : (
            appointment_.map((record) => (
              <div className='record2' key={record.record_id}>
                <p>Found  appointment_id: {record.record_id}</p>
                <p>Identification: {record.patient_id}</p>
                <p>doctor_id: {record.doctor_id}</p>
                <p>appointment_date: {record.appointment_date}</p>
                <p>Hospital ID: {record.hospital_id}</p>
              </div>
            ))
          )}
      
          <Link to='/patient_view'>
            <button className='btn8'>Back</button>
          </Link>
        </div>
  )
}

export default Appointment
