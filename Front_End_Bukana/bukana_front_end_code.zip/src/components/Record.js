import React from 'react'
import {Link} from 'react-router-dom'


const Record = ({record_}) => {
    return (
        <div className='record1'>
          {record_.length === 0 ? (
            <h>Patient has no record</h>
          ) : (
            record_.map((record) => (
              <div className='record2' key={record.record_id}>
                <p>Found record with ID: {record.record_id}</p>
                <p>Identification: {record.patient_id}</p>
                <p>Symptoms: {record.symptoms}</p>
                <p>Prescription: {record.medication}</p>
                <p>Date: {record.record_date}</p>
                <p>Hospital ID: {record.hospital_id}</p>
              </div>
            ))
          )}
      
          <Link to='/result'>
            <button className='btn8'>Back</button>
          </Link>
        </div>
      );
      
}

export default Record
