import React from 'react'
import {Link} from 'react-router-dom'


const MyRecord = ({my_record}) => {
    return (
        <div className='record1'>
          {my_record.length === 0 ? (
            <h>Patient has no record</h>
          ) : (
            my_record.map((record) => (
              <div className='record2' key={record.record_id}>
                <p>Found record with ID: {record.record_id}</p>
                <p>Identification: {record.patient_id}</p>
                <p>Symptoms: {record.symptoms}</p>
                <p>Prescription: {record.medication}</p>
                <p>Date: {record.record_date}</p>
                <p>Hospital ID: {record.hospital_id}</p>
              </div>
            ))
          )}
      
          <Link to='/patient_view'>
            <button className='btn8'>Back</button>
          </Link>
        </div>
      );
      
}

export default MyRecord
