import React from 'react';
import { useState } from 'react';

import { Link, useNavigate } from 'react-router-dom';

const Patient = () => {
  const [patient_id, setPatient_id] = useState('');
  const [name, setName] = useState('');
  const [district_id, setDistrict_id] = useState('');
  const [email, setEmail] = useState('');
  const [number, setNumber] = useState('');

  const navigate = useNavigate();

  const createPatient = () => {
    fetch('http://localhost:3001/patient', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ patient_id, name, district_id, email, number }),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Failed to create patient');
        }
        return response.text();
      })
      .then((data) => {
        alert(data);
        // Additional logic after successful creation
      })
      .catch((error) => {
        console.error(error);
        // Handle the error: display a message or perform any necessary actions
      });
  };

  const handleCreateClick = () => {
    createPatient();
    navigate('/create');
  };

  return (
    <div className='patient1'>
      <div className='information'>
        <input
          type='text'
          placeholder='patient_id'
          value={patient_id}
          onChange={(e) => setPatient_id(e.target.value)}
        />
        <input
          type='text'
          placeholder='name'
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type='text'
          placeholder='district_id'
          value={district_id}
          onChange={(e) => setDistrict_id(e.target.value)}
        />
        <input
          type='email'
          placeholder='email'
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type='number'
          placeholder='whatsApp_number'
          value={number}
          onChange={(e) => setNumber(e.target.value)}
        />
      </div>
      <div  className='buttons'>

        <Link to={'/create'}>
          <button className='btn11'>Back</button>
        </Link>
        <button className='btn4' onClick={handleCreateClick}>
          create
        </button>

      </div>
      
    </div>
  );
};

export default Patient;
