import React,{useState,useContext} from 'react'
import {Link,useNavigate,Navigate} from 'react-router-dom'
import { AuthContext } from './AuthContext';
import Patient_view from './Patient_view';



const Create = ({authorized,who}) => {
  const {searchpatient,setrecord} = useContext(AuthContext);

  const [search_patient,set_search]=useState('');
  const navigate = useNavigate();

  const onhandleLoginClick = () => {
     navigate('/login');

  };
  const handleLoginClick = () => {
    searchpatient(search_patient);
    setrecord(search_patient);
    navigate('/');
  };
  
  if(who && authorized){
    return <Patient_view/>
  }
  else if((!who) && authorized){
    return (
      <form className='create'>
          
              <h1 className='heading'>Enter the ID number of the patient </h1>
        
          <div className='create2'>
              <div className='create3'>
                   <input type='text' placeholder='search the patient' 
                   className='search'  
                   value={search_patient}
                   onChange={e => set_search(e.target.value)}/>
                   <Link to="/result" onClick={handleLoginClick}>
                       <button className='btn2'>Search</button>
                   </Link>
              </div>
              
              <h1>Or create new patient </h1>
              <Link to={'/patient'} onClick={onhandleLoginClick}>
               <button className='btn3'>create patient account</button>
              </Link>
              <Link to={'/login'} >
                <button className='btn10'>Logout</button>
              </Link>
  
          </div>
  
      </form>
     
    )
    
  }else{
    return <Navigate to={'/login'}/>
  }
 
}

export default Create
