import React from 'react';
import {Link,useNavigate,Navigate} from 'react-router-dom'


const Results = ({ result }) => {
  return (
    <div className='result'>
      {result === null ? (
        <p>No patient found. Please try again with correct credentials.</p>
      ) : (
        <div className='result2'>
          <p>Found patient with name :{result.name}</p>
          <p>Identification          :{result.patient_id}</p>
          <p>District_id             :{result.district_id}</p>
          <p>Email                   :{result.email}</p>
        </div>
      )}

     <div className='what_to_do'>
       <Link to={'/create'}>
        <button className='btn6'>Back</button>
       </Link>
       <Link to={'/viewrecord'}>
        <button className='btn6'>View Record</button>
       </Link>
      <Link to={'/updateRecord'}>
         <button className='btn7'>Update Record</button>
      </Link>
     </div>
    </div>
  );
};

export default Results;
