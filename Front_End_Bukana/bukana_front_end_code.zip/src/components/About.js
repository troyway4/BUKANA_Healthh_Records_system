import {React} from 'react'
import {Link,useNavigate} from 'react-router-dom'



const About = () => {
  
  
  const navigate = useNavigate();

  const handleLoginClick = () => {
    navigate('/login');
  };

  return (
    <div className='about'>
        <h1>Welcome to a patient record system based in Lesotho</h1>
        <h1>Click login to access the system</h1>
        <Link to='/login' onClick={handleLoginClick}>
          <button className='btn5'>login to system </button>
        </Link>
       
    </div>
  )
}

export default About
