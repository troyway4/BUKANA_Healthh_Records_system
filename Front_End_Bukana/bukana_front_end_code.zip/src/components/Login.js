import React, { useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from './AuthContext';
import Footer from './Footer';


const Login = () => {
  const { setUsername, setPassword } = useContext(AuthContext);
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const navigate = useNavigate();

  const handleLoginClick = () => {
    setUsername(usernameInput);
    setPassword(passwordInput);
    navigate('/');
  };

  return (
    <form className="login">
      <input
        type="text"
        placeholder="Username"
        className="username"
        value={usernameInput}
        onChange={e => setUsernameInput(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        className="password"
        value={passwordInput}
        onChange={e => setPasswordInput(e.target.value)}
      />
      <div className='homepage'>
          <Link to="/create" onClick={handleLoginClick}>
            <button className="btn1">Login</button>
          </Link>
          <Link to="/" onClick={handleLoginClick}>
            <button className="btn1">Home</button>
          </Link>
      </div>
     
      <Footer />
    </form>
  );
};
export default Login;