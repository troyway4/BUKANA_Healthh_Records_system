import React from 'react'

const Header = () => {
  return (
    <div className='header'>
      <div >
       < h1 className='bukana'><b>BUKANA</b></h1>
      </div>
    
    </div>
  )
}

export default Header
