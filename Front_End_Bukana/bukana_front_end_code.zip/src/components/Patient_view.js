import React from 'react'
import {Link,useNavigate} from 'react-router-dom'


const Patient_view = () => {


  return (
    <div className='view'>
      <div className='view1'>
      <h1 className='view4'>WELCOME PATIENT</h1>
      </div>
      <div className='view2'>
        <Link to='/record_view'>
          <button>View Record</button>
        </Link>
       <Link to={'/appointment'}>
         <button>View Appoinment</button>
       </Link>
      </div>
      <Link to={'/login'} >
                <button className='btn10'>Logout</button>
              </Link>
    </div>
  )
}

export default Patient_view
