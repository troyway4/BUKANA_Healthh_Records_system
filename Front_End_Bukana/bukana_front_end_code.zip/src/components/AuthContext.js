import React, { createContext, useState } from 'react';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [_record,setrecord]=useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [patient_result,searchpatient]=useState('');

  return (
    <AuthContext.Provider value={{ username, password,patient_result,_record,setrecord, setUsername, setPassword,searchpatient }}>
      {children}
    </AuthContext.Provider>
  );
};
