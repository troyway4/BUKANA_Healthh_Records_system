import React, { useContext,useState ,useEffect} from 'react';
import Header from './components/Header';
import Login from './components/Login';
import Footer from './components/Footer';
import Create from './components/Create';
import Patient from './components/Patient';
import About from './components/About';
import Results from './components/Results';
import { BrowserRouter as Router, Switch, Route, Routes } from 'react-router-dom';
import { AuthContext } from './components/AuthContext';

import './App.css';
import Record from './components/Record';
import UpdateRecord from './components/UpdateRecord';
import Patient_view from './components/Patient_view';
import MyRecord from './components/MyRecord';
import Appointment from './components/Appointment';

function App() {
  const [patient_record, setRecord] = useState('[]');
  const [users, setusers] = useState('[]');
  const [patient, setPatient] = useState('[]');
  const [appointment,setappointment]=useState('[]');
  useEffect(() => {
    getappointment();
  }, []);

  function getappointment() {
    fetch('http://localhost:3001/appointment')
      .then(response => {
        return response.json(); // Parse response as JSON
      })
      .then(data => {
        setappointment(data); // Access the username property
      });
  }
  useEffect(() => {
    getusers();
  }, []);

  function getusers() {
    fetch('http://localhost:3001')
      .then(response => {
        return response.json(); // Parse response as JSON
      })
      .then(data => {
        setusers(data); // Access the username property
      });
  }
  useEffect(() => {
    getPatient();
  }, []);

  function getPatient() {
    fetch('http://localhost:3001/result')
      .then(response => {
        return response.json(); // Parse response as JSON
      })
      .then(data => {
        setPatient(data); // Access the username property
      });
  }

  useEffect(() => {
    getRecord();
  }, []);

  function getRecord() {
    fetch('http://localhost:3001/record')
      .then(response => {
        return response.json(); // Parse response as JSON
      })
      .then(data => {
        setRecord(data); // Access the username property
      });
  }
  
const { username, password ,patient_result,_record} = useContext(AuthContext);
let result_ = null;
let patient_record_ = [];
let mine_record=[];
let ifmine=[];


for (let i = 0; i < appointment.length; i++) {
  if (username == appointment[i].patient_id) {
    ifmine.push(appointment[i]);
  }
}

for (let i = 0; i < patient_record.length; i++) {
  if (username == patient_record[i].patient_id) {
    mine_record.push(patient_record[i]);
  }
}


for (let i = 0; i < patient_record.length; i++) {
  if (_record == patient_record[i].patient_id) {
    patient_record_.push(patient_record[i]);
  }
}

for (let i = 0; i < patient.length; i++) {
  if (patient_result == patient[i].patient_id) {
    result_ = patient[i];
    break; // Exit the loop after finding the result
  }
}
  
  let auth = false;
  let isPatient = false;
  for(let i=0;i<users.length;i++){
    if ( username === users[i].username && password === users[i].password) {
      auth = true;
      if(users[i].ispatient==true){
        isPatient=true;
        break;
      }
      break;
    }
    
  }

 


  return (
    <Router>
      <div>
        {/* <h>{patient_record_.record_id}</h> */}
        <Header />
        {/* <h1>{isPatient}</h1> */}
        {/* <h1>{mine_record[0].patient_id}</h1>
         */}
        <Routes>
          <Route exact path="/" Component={About} />
          <Route path="/login" Component={Login} />
          <Route path="/create" Component={() => <Create authorized={auth} who={isPatient} />} />
          <Route path="/patient" Component={Patient} />
          <Route path="/result" Component={() => <Results result={result_ } />} />
          <Route path="/viewrecord" Component={() => <Record record_={patient_record_ } />} />
          <Route path="/updateRecord" Component={UpdateRecord} />
          <Route path="/patient_view" Component={Patient_view} />
          <Route path="/record_view" Component={() => <MyRecord my_record={mine_record}/>} />
          <Route path="/appointment" Component={() => <Appointment appointment_={ifmine}/>} />
        </Routes>

      </div>
   </Router>
  );
}

export default App;
